/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   output.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dlesieur <dlesieur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/21 14:59:40 by syzygy            #+#    #+#             */
/*   Updated: 2026/01/23 23:17:05 by dlesieur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OUTPUT_H
# define OUTPUT_H

# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include "ft_memory.h"
# include "error.h"

typedef struct s_state_fd	t_state_fd;

# define OUTPUT_ERR 01
# define OUTBUFSIZE 1024

typedef struct s_out
{
	char	*nextc;
	char	*end;
	char	*buf;
	size_t	buf_size;
	int		fd;
	int		flags;
}	t_out;

typedef struct s_out_ctx
{
	t_out	output;
	t_out	prev_err_out;
	t_out	errout;
	t_out	memout;
	t_out	*out1;
	t_out	*out2;
}	t_out_ctx;

typedef struct s_fdio
{
	int				fd;
	int				flags;
	char			*io_read_ptr;
	char			*io_read_end;
	char			*io_read_base;
	char			*io_write_base;
	char			*io_write_ptr;
	char			*io_write_end;
	char			*io_buf_base;
	char			*io_buf_end;
	char			*io_save_base;
	char			*io_bak;
	char			*save_end;
	struct s_file	*chain;
	int				flags2;
	unsigned short	cur_column;
	signed char		vable_offset;
	char			short_buf[1];
	void			*lock;
}	t_fdio;

static inline t_out_ctx	*get_outs(void)
{
	static t_out_ctx	ctx;
	static int			inited = 0;

	if (inited)
		return (&ctx);
	ctx.output.buf_size = OUTBUFSIZE;
	ctx.output.fd = STDOUT_FILENO;
	ctx.prev_err_out.buf_size = OUTBUFSIZE;
	ctx.prev_err_out.fd = STDERR_FILENO;
	ctx.errout.buf_size = OUTBUFSIZE;
	ctx.errout.fd = STDERR_FILENO;
	ctx.memout.buf_size = OUTBUFSIZE;
	ctx.memout.fd = STDOUT_FILENO;
	ctx.out1 = &ctx.output;
	ctx.out2 = &ctx.errout;
	inited = 1;
	return (&ctx);
}

void	ft_putchar_fd(const char c, int fd);
void	ft_putendl_fd(const char *s, int fd);
void	ft_putnbr_base(int nbr, char *radix);
void	ft_putnbr_fd(const int nb, int fd);
void	ft_putstr_fd(const char *s, int fd);

/* flush helpers used by error/format modules */
void	flushout(t_out *dst);
void	flush_all(void);
int		ft_write(int fd, const void *p, size_t n);
void	trputs(const char *s);
void	tracev(const char *fmt, va_list va);
void	trace(const char *fmt, ...);
void	trputc(int c);
void	indent(int amount, char *pfx, int fd);
void	set_debug(int newval);
void	set_trace_fd(int newfd);
int		*debug_ptr(void);
int		get_trace_fd(void);
int		*tracefd_ptr(void);
void	out1fmt(const char *fmt, ...);
void	outmem(const char *p, size_t len, t_out *dst);
int		log_print(t_state_fd *state, const char *file, const char *format, ...);
int		ft_sprintf(char *dst, const char *format, ...);
int		ft_snprintf(char *dst, size_t cap, const char *format, ...);
int		ft_printf(const char *format, ...);
int		ft_dprintf(int fd, const char *format, ...);
int		ft_aprintf(char **dst, const char *format, ...);
void	flush_all(void);
int		fmtstr(char *outbuf, size_t length, const char *fmt, ...);
int		ft_eprintf(const char *str, ...);
char	*ft_aseprintf(const char *str, ...);
void	ft_eputmem(char *s, int n);
void	ft_putmem(char *s, int n);
void	ft_fdputmem(int fd, char *s, int n);

#endif
