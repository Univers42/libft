/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sprintf.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/21 15:21:26 by syzygy            #+#    #+#             */
/*   Updated: 2026/01/11 00:20:58 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../format/format.h"

//int	ft_sprintf(char *dst, const char *format, ...)
//{
//	va_list	ap;
//	int		return_value;
//
//	va_start(ap, format);
//	return_value = ft_vsnprintf(dst, (size_t)-1, format, &ap);
//	va_end(ap);
//	return (return_value);
//}
//